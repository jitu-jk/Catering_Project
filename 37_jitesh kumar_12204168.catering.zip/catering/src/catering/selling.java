/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package catering;
import javax.swing.*;
import java.util.*;
import static java.lang.System.exit;
import java.sql.*;
import  java.time.LocalDateTime;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;


/**
 *
 * @author my pc
 */
public class selling extends javax.swing.JFrame {

    /**
     * Creates new form selling
     */
    public selling() {
        initComponents();
        ShowProducts();
        
        PriceTb.setEditable(false);
        SellerTb.setEditable(true);
        PrNameTb.setEditable(false);
        
    }
ResultSet rs=null,rs1=null;
Connection con =null;
Statement st=null,st1=null;

private void ShowProducts()
{
try
{ 
    con=DriverManager.getConnection("jdbc:mysql:///cateringdb","root","root123");
    st=con.createStatement();
    rs=st.executeQuery("select* from ProductTb1");
    jTable2.setModel(DbUtils.resultSetToTableModel(rs));
}
catch(Exception e)
{
}
}

int BNum;
private void CountBill()
{
    try
    {
       st1 = con.createStatement(); 
       rs1 = st1.executeQuery("select Max(BNum) from BillTb1");
       rs1.next();
       BNum = rs1.getInt(1)+1;
    }
    catch (Exception e){
}
}   

    private void InsertBill()
    {
     
          try{
              CountBill();
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cateringdb","root","root123");
               PreparedStatement Pst = con.prepareStatement("insert into BillTb1 values(?,?,?,?)");
                       Pst.setInt(1, BNum);
                        Pst.setString(2, SellerTb.getText());
                        LocalDateTime now = LocalDateTime.now();
                        Pst.setString(3,now.toString());
                        Pst.setInt(4,GrdTot);
                        int row =Pst.executeUpdate();
                        JOptionPane.showMessageDialog(this, "Bill Added!!!");
                        con.close();
                        ShowProducts();
          } 
          catch(SQLException ex){
                
              JOptionPane.showMessageDialog(this,ex);
                  }
            
        
        
        
        
        
    }
    @SuppressWarnings("unchecked")
    
     private void FilterProducts()
{
    try{
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cateringdb","root","root123");
        st = con.createStatement();
        rs = st.executeQuery("Select * from ProductTb1 where Category ='"+jComboBox1.getSelectedItem().toString()+"'");
        jTable2.setModel(DbUtils.resultSetToTableModel(rs));
    } catch(Exception e){
        JOptionPane.showMessageDialog(this,e);
}
}
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        name = new java.awt.Label();
        PrNameTb = new java.awt.TextField();
        label4 = new java.awt.Label();
        name1 = new java.awt.Label();
        name2 = new java.awt.Label();
        PriceTb = new java.awt.TextField();
        PrintBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        BillTable = new javax.swing.JTable();
        PrQtyTb = new javax.swing.JTextField();
        SellerTb = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        TotalLb1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        name3 = new java.awt.Label();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(102, 255, 51));
        jPanel1.setVerifyInputWhenFocusTarget(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        name.setAlignment(java.awt.Label.CENTER);
        name.setBackground(new java.awt.Color(255, 255, 204));
        name.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        name.setText("Buyer");
        jPanel1.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 100, -1));
        jPanel1.add(PrNameTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 92, 105, 30));

        label4.setAlignment(java.awt.Label.CENTER);
        label4.setBackground(new java.awt.Color(255, 255, 255));
        label4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        label4.setText("Menu Details");
        jPanel1.add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 0, 112, 31));

        name1.setAlignment(java.awt.Label.CENTER);
        name1.setBackground(new java.awt.Color(255, 255, 204));
        name1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        name1.setText("Name");
        jPanel1.add(name1, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 61, 105, -1));

        name2.setAlignment(java.awt.Label.CENTER);
        name2.setBackground(new java.awt.Color(255, 255, 204));
        name2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        name2.setText("Quantity");
        jPanel1.add(name2, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 61, 105, -1));

        PriceTb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PriceTbActionPerformed(evt);
            }
        });
        jPanel1.add(PriceTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(429, 92, 105, 30));

        PrintBtn.setBackground(new java.awt.Color(153, 153, 255));
        PrintBtn.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        PrintBtn.setText("Print");
        PrintBtn.setToolTipText("");
        PrintBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 255), new java.awt.Color(102, 255, 255), new java.awt.Color(255, 102, 102), new java.awt.Color(204, 102, 255)));
        PrintBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintBtnActionPerformed(evt);
            }
        });
        jPanel1.add(PrintBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 470, 96, 34));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setText("Your Bill");
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 255, 255), new java.awt.Color(255, 102, 102), new java.awt.Color(204, 102, 255)));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(549, 171, 73, 23));

        BillTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Price", "Quantity", "Total"
            }
        ));
        BillTable.setRowHeight(30);
        BillTable.setShowHorizontalLines(true);
        BillTable.setShowVerticalLines(true);
        jScrollPane1.setViewportView(BillTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(419, 221, 337, 188));
        jPanel1.add(PrQtyTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 92, 105, 30));
        jPanel1.add(SellerTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(585, 92, 105, 30));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Category", "Price"
            }
        ));
        jTable2.setRowHeight(30);
        jTable2.setShowHorizontalLines(true);
        jTable2.setShowVerticalLines(true);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 221, 312, 188));

        jButton4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton4.setText("Add To Bill");
        jButton4.setToolTipText("");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 255), new java.awt.Color(153, 255, 255), new java.awt.Color(255, 102, 102), new java.awt.Color(204, 102, 255)));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 159, -1, -1));

        TotalLb1.setBackground(new java.awt.Color(255, 255, 255));
        TotalLb1.setFont(TotalLb1.getFont().deriveFont(TotalLb1.getFont().getStyle() | java.awt.Font.BOLD, TotalLb1.getFont().getSize()+4));
        TotalLb1.setText("Total");
        TotalLb1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 255), new java.awt.Color(102, 255, 255), new java.awt.Color(255, 102, 102), new java.awt.Color(255, 102, 255)));
        jPanel1.add(TotalLb1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 430, 50, -1));

        jComboBox1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Basic", "Standard", "Beverage", "Snacks", "Desserts", "Chinese" }));
        jComboBox1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 255), new java.awt.Color(102, 255, 255), new java.awt.Color(255, 102, 102), new java.awt.Color(255, 102, 255)));
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 158, -1, 24));

        jLabel7.setBackground(new java.awt.Color(255, 255, 204));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/catering/WhatsApp Image 2023-05-10 at 7.31.08 PM.jpeg"))); // NOI18N
        jLabel7.setText("jLabel7");
        jLabel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, new java.awt.Color(204, 255, 255), null, null));
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -120, 850, 650));

        name3.setAlignment(java.awt.Label.CENTER);
        name3.setBackground(new java.awt.Color(153, 255, 255));
        name3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        name3.setText("Price");
        jPanel1.add(name3, new org.netbeans.lib.awtextra.AbsoluteConstraints(429, 61, 105, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(86, 6, -1, 565));

        jLabel2.setBackground(new java.awt.Color(204, 204, 255));
        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setText("Items");
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 255), new java.awt.Color(102, 255, 255), new java.awt.Color(255, 102, 102), new java.awt.Color(255, 102, 255)));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 70, 67, 26));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setText("Selling");
        jLabel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 255), new java.awt.Color(102, 255, 255), new java.awt.Color(255, 102, 153), new java.awt.Color(204, 102, 255)));
        jLabel4.setMaximumSize(new java.awt.Dimension(80, 21));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 105, 67, 20));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setText("LOGOUT");
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 255), new java.awt.Color(102, 255, 255), new java.awt.Color(255, 102, 102), new java.awt.Color(255, 102, 255)));
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 480, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setText("Viewsells");
        jLabel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 255), new java.awt.Color(102, 255, 255), new java.awt.Color(255, 102, 102), new java.awt.Color(204, 102, 255)));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 137, -1, 27));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PriceTbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PriceTbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PriceTbActionPerformed

    private void PrintBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintBtnActionPerformed
       try{
           InsertBill();
           BillTable.print();
       }
       catch(Exception e) {
           
       }
    }//GEN-LAST:event_PrintBtnActionPerformed
     int GrdTot = 0;
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
      if(PrNameTb.getText().isEmpty()|| PrQtyTb.getText().isEmpty()){
          JOptionPane.showMessageDialog(this,"Missing Information!!!");
          
      }else{
         
          int Total=Integer.valueOf(PriceTb.getText())* Integer.valueOf(PrQtyTb.getText());
           GrdTot = GrdTot + Total;
           TotalLb1.setText("Rs"+GrdTot);
         DefaultTableModel model= (DefaultTableModel) BillTable.getModel();
         String nextRowId = Integer.toString(model.getRowCount());
         model.addRow(new Object[]{
           Integer.valueOf(nextRowId)+1,
        PrNameTb.getText(),
        PriceTb.getText(),
        PrQtyTb.getText(),
        SellerTb.getText(),
        Total 
                  
         });
         }
    
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        new items().setVisible(true);
         this.dispose();
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        new login().setVisible(true);
         this.dispose();
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        new viewsells().setVisible(true);
         this.dispose();
                       
    }//GEN-LAST:event_jLabel6MouseClicked
  int key = 0;
    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked

        DefaultTableModel model= (DefaultTableModel) jTable2.getModel();
        int MyIndex= jTable2.getSelectedRow();
        key=Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        PrNameTb.setText(model.getValueAt(MyIndex,1).toString());
       PriceTb.setText(model.getValueAt(MyIndex,3).toString());
   
    }//GEN-LAST:event_jTable2MouseClicked

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
         FilterProducts();
    }//GEN-LAST:event_jComboBox1ItemStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
           

           
       
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new selling().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable BillTable;
    private java.awt.TextField PrNameTb;
    private javax.swing.JTextField PrQtyTb;
    private java.awt.TextField PriceTb;
    private javax.swing.JButton PrintBtn;
    private javax.swing.JTextField SellerTb;
    private javax.swing.JLabel TotalLb1;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    private java.awt.Label label4;
    private java.awt.Label name;
    private java.awt.Label name1;
    private java.awt.Label name2;
    private java.awt.Label name3;
    // End of variables declaration//GEN-END:variables

  }